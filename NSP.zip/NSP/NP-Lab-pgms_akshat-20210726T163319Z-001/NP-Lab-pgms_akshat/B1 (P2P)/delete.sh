

 find . -name "*.nam" -type f -delete
 find . -name "*.tr" -type f -delete


   
