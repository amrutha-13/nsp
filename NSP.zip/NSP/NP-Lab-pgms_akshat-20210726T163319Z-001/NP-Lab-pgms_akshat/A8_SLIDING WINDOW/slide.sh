cc server.c -w -o s
cc client.c -w -o c



fuser -k 5000/tcp



echo " open terminal  type ./s  , another terminal  type ./c  "

# ./s 
# ./c
